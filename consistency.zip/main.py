mode  = input("Enter the the mode Training / Testing :- ")
while True:
    if mode.lower() == "training":
        from Training import Training
        break
    elif mode.lower() == "testing":
        print("testing")
        from Testing import Testing
        Testing()
        break
    else:
        print("Invalid mode entered")
        continue